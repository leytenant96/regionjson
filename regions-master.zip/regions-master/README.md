# regions
Viloyat, tuman &amp; shahar, OFY, MFY, QFYlar ro'yhati MySQL, JSON shaklida

# stat
regions = 15
distircts = 202
quarters = 10027
